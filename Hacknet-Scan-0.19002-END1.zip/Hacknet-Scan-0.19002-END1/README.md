
# Hacknet-Scan
The Hacknet Extension.

[简体中文](https://github.com/Pr0j3c1X/Hacknet-Scan/wiki/README-中文)

## Main Developer
@HuiNight

## Developers
@Xenoex
@Thesjy
...


## Music
DJ Striden - Wave World

### Need DLC!
